# CLI Reference v4.1.0+

This page lists all available command-line options and configuration keys for `entkapp v4.1.0+`.

```text
Usage: entkapp [options]

Ultimate Enterprise Codebase Janitor & Self-Healing Engine

Options:
  -V, --version          output the version number
  -c, --cwd <path>       Specify the execution context root directory
  -r, --run              Execute the primary operational pipeline loop
  --fix                  Enable atomic code updates and self-healing
  --no-fix               This Method is Deprecated in v4.5.1+ (default: true)
  --tsconfig <path>      Specify path to custom layout configurations
  --test-command <cmd>   Integrated safety test validation script (default: "npm test")
  --workspace            Enable monorepo cluster mesh evaluation
  --verbose              Toggle expanded trace telemetry for diagnostics
  -y, --yes              Skip confirmation prompts for automatic execution
  --init                 Initialize a new entkapp configuration in the current directory
  --timeout <ms>         Set execution timeout in milliseconds (default: 30000)
  -h, --help             display help for command
  --debug                Developer's Help Tool, for debugging
```

## Options in Detail

### `-V`, `--version`
Displays the current version of `entkapp`.

### `-c`, `--cwd <path>`
Defines the root directory where `entkapp` should be executed.

### `-r`, `--run`
Initiates the analysis and refactoring process. This is required for execution.

### `--fix`
Controls whether the engine should apply changes to the filesystem.

### `--init`
Automatically sets up the `/entkapp` directory and a default `config.json` in your project root.

### `--workspace`
Enables deep analysis of monorepos, linking dependencies across multiple packages. **v3.3.8+ automatically detects monorepo layouts.**

### Secrets Scanning (v3.3.8+)
The engine now automatically scans for hardcoded secrets and credentials during the analysis pass. Findings are reported in the summary and can be suppressed using `@scaffold-suppress` comments.

## Plugin API Reference (v3.3.8+)

### `BasePlugin` Methods

| Method | Description | Return Type |
| --- | --- | --- |
| `get name()` | Unique identifier for the plugin | `string` |
| `getConfigFiles()` | Files that trigger plugin activation | `string[]` |
| `getRoutePatterns()` | Regex for entry point detection | `RegExp[]` |
| `getRequiredSystemContracts()` | Symbols that must be preserved | `string[]` |
| `get(key)` | **New in v3.2.0.** Dynamic getter for custom properties | `any` |
| `isActive(dir)` | Async check for project compatibility | `Promise<boolean>` |

### Configuration (`entkapp/config.json`)

```json
{
  "interface": "CLI",
  "useBuiltinPlugins": true,
  "useCustomPlugins": true,
  "options": {
    "verbose": false,
    "fastMode": true,
    "selfHealing": true
  },
  "enabledPlugins": ["nextjs", "nuxt", "remix", "sveltekit", "astro"]
}
```
